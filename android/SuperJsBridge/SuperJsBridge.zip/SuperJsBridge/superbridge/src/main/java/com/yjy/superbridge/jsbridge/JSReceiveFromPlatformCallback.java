package com.yjy.superbridge.jsbridge;

import com.yjy.superbridge.internal.ReceiveFromPlatformCallback;

/**
 * <pre>
 *     author : yjy
 *     e-mail : yujunyu12@gmail.com
 *     time   : 2020/08/06
 *     desc   :
 *     version: 1.0
 * </pre>
 */
public interface JSReceiveFromPlatformCallback extends ReceiveFromPlatformCallback<Message> {
}
