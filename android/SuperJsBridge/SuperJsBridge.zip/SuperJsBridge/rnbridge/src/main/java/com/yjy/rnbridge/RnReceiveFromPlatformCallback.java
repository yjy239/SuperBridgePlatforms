package com.yjy.rnbridge;

import com.yjy.superbridge.internal.ReceiveFromPlatformCallback;

/**
 * <pre>
 *     author : yjy
 *     e-mail : yujunyu12@gmail.com
 *     time   : 2020/08/10
 *     desc   :
 *     version: 1.0
 * </pre>
 */
public interface RnReceiveFromPlatformCallback extends ReceiveFromPlatformCallback<String> {
}
