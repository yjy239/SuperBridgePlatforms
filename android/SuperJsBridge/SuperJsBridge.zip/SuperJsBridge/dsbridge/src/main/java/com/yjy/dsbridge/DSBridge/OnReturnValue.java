package com.yjy.dsbridge.DSBridge;

/**
 * Created by du on 16/12/31.
 */

public interface OnReturnValue<T> {
    void onValue(T retValue);
}
