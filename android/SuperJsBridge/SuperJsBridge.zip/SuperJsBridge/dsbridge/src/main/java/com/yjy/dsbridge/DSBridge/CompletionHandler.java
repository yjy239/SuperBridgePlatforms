package com.yjy.dsbridge.DSBridge;

import com.yjy.superbridge.internal.CallBackHandler;

/**
 * Created by du on 16/12/31.
 */

public interface  CompletionHandler<T> extends CallBackHandler {
}
