package com.yjy.superjsbridgedemo.model;

/**
 * <pre>
 *     author : yjy
 *     e-mail : yujunyu12@gmail.com
 *     time   : 2020/08/06
 *     desc   :
 *     version: 1.0
 * </pre>
 */
public class TestObj {
    public String name;
    public int age;
}
