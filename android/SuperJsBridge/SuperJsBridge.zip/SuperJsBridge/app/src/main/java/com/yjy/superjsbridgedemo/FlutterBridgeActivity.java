package com.yjy.superjsbridgedemo;

import io.flutter.embedding.android.FlutterActivity;

/**
 * <pre>
 *     author : yjy
 *     e-mail : yujunyu12@gmail.com
 *     time   : 2020/09/02
 *     desc   :
 *     version: 1.0
 * </pre>
 */
public class FlutterBridgeActivity extends FlutterActivity {
}
